
""" This module loads all the classes from the vtkSlicerSuperBuildLoadableExtensionTemplateModuleLogic library into its
namespace."""

from vtkSlicerSuperBuildLoadableExtensionTemplateModuleLogicPython import *
