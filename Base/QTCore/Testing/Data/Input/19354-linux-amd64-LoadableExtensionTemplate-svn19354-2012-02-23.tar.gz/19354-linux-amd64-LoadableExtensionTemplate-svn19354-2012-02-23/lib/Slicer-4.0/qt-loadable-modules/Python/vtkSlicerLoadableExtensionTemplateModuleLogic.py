
""" This module loads all the classes from the vtkSlicerLoadableExtensionTemplateModuleLogic library into its
namespace."""

from vtkSlicerLoadableExtensionTemplateModuleLogicPython import *
